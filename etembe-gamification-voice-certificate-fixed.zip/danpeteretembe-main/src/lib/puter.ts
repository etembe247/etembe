// ETEMBE AI runs entirely through Puter.js — free forever, no API key.
// The script loads from https://js.puter.com/v2/ in the root document head.

type PuterStreamChunk = { text?: string; message?: { content?: string }; choices?: Array<{ delta?: { content?: string }; message?: { content?: string } }> };
type PuterChatResult = { message?: { content?: string }; text?: string } & AsyncIterable<PuterStreamChunk>;
type PuterAI = {
  chat: (prompt: unknown, ...args: unknown[]) => Promise<PuterChatResult>;
  txt2img: (prompt: string) => Promise<HTMLImageElement>;
  txt2speech: (text: string) => Promise<HTMLAudioElement>;
};
declare global { interface Window { puter?: { ai: PuterAI } } }

export class PuterAuthError extends Error {}

const MODEL = 'qwen/qwen3-0.6b';

function ai(): PuterAI {
  const puter = typeof window !== 'undefined' ? window.puter?.ai : undefined;
  if (!puter) throw new PuterAuthError('ETEMBE AI is still loading. Check your internet and try again.');
  return puter;
}

function wrap(error: unknown): Error {
  const message = error instanceof Error ? error.message : String(error ?? '');
  if (/allow|auth|permission|denied|popup|sign.?in/i.test(message)) return new PuterAuthError('Please Allow ETEMBE AI');
  return error instanceof Error ? error : new Error(message || 'ETEMBE AI could not respond.');
}

// ---- Fallbacks: Pollinations.ai (online, key-free) then Qwen2 1.5B in-browser (offline) ----
const QWEN_MODEL = 'Qwen2-1.5B-Instruct-q4f16_1-MLC';
type QwenEngine = { chat: { completions: { create: (o: unknown) => Promise<AsyncIterable<{ choices: { delta?: { content?: string } }[] }>> } } };
let qwenPromise: Promise<QwenEngine> | null = null;

/** Lazily downloads (once, then cached by the browser) and starts Qwen2 1.5B via WebGPU. */
export function loadQwen(onProgress?: (text: string) => void): Promise<QwenEngine> {
  if (!qwenPromise) {
    if (typeof navigator === 'undefined' || !('gpu' in navigator)) return Promise.reject(new Error('This device does not support offline AI (WebGPU needed).'));
    qwenPromise = import('@mlc-ai/web-llm')
      .then(m => m.CreateMLCEngine(QWEN_MODEL, { initProgressCallback: (r: { text: string }) => onProgress?.(r.text) }) as unknown as Promise<QwenEngine>)
      .catch(e => { qwenPromise = null; throw e; });
  }
  return qwenPromise;
}

async function qwenChat(prompt: string, onChunk?: (partial: string) => void): Promise<string> {
  const engine = await loadQwen(t => onChunk?.(`⏳ Loading offline AI… ${t}`));
  const stream = await engine.chat.completions.create({ messages: [{ role: 'user', content: prompt }], stream: true });
  let out = '';
  for await (const c of stream) { const p = c.choices[0]?.delta?.content ?? ''; if (p) { out += p; onChunk?.(out); } }
  return out;
}

async function pollinationsChat(prompt: string, onChunk?: (partial: string) => void): Promise<string> {
  const res = await fetch(`https://text.pollinations.ai/${encodeURIComponent(prompt.slice(0, 6000))}`);
  if (!res.ok) throw new Error(`Pollinations ${res.status}`);
  const text = await res.text();
  onChunk?.(text);
  return text;
}

const isOffline = () => typeof navigator !== 'undefined' && navigator.onLine === false;

async function puterOnly(prompt: string, image?: string | null, onChunk?: (partial: string) => void): Promise<string> {
  const messages = [{ role: 'user', content: image ? [{ type: 'text', text: prompt }, { type: 'image_url', image_url: { url: image } }] : prompt }];
  const result = await ai().chat(messages, { model: MODEL, stream: true });
  if (result && typeof result[Symbol.asyncIterator] === 'function') {
    let out = '';
    for await (const chunk of result) {
      const value = chunk?.text ?? chunk?.message?.content ?? chunk?.choices?.[0]?.delta?.content ?? chunk?.choices?.[0]?.message?.content ?? '';
      const piece = typeof value === 'string' ? value : value ? JSON.stringify(value) : '';
      if (piece) { out += piece; onChunk?.(out); }
    }
    return out;
  }
  const text = typeof result === 'string' ? result : result?.message?.content || result?.text || JSON.stringify(result);
  onChunk?.(text);
  return text;
}

/** Chat: Puter.js first, then Pollinations.ai online; WebLLM is loaded only while offline. */
export async function puterChat(prompt: string, image?: string | null, onChunk?: (partial: string) => void): Promise<string> {
  if (isOffline()) return qwenChat(prompt, onChunk);
  let firstError: unknown;
  try {
    const out = await puterOnly(prompt, image, onChunk);
    if (out.trim()) return out;
  } catch (error) { firstError = error; }
  try { return await pollinationsChat(prompt, onChunk); } catch { throw wrap(firstError ?? new Error('ETEMBE AI could not respond.')); }
}

/** Generate an image: Puter.js first, Pollinations.ai fallback. */
export async function puterImage(prompt: string): Promise<string> {
  try {
    const img = await ai().txt2img(prompt);
    if (img?.src) return img.src;
  } catch { /* fall through */ }
  return `https://image.pollinations.ai/prompt/${encodeURIComponent(prompt)}?nologo=true`;
}

/** Speak text aloud; returns the playing audio element. */
export async function puterSpeech(text: string): Promise<HTMLAudioElement> {
  try {
    const audio = await ai().txt2speech(text);
    await audio.play();
    return audio;
  } catch (error) { throw wrap(error); }
}

export type AiMode = 'online' | 'limit' | 'offline';
let lastMode: AiMode = 'online';
/** Which engine answered the most recent request (for the "Offline AI" badge). */
export const lastAiMode = () => lastMode;

/** askAI: Puter qwen/qwen3-0.6b → Pollinations.ai online; in-browser Qwen2 1.5B only offline. */
export async function askAI(prompt: string, image?: string | null, onChunk?: (partial: string) => void): Promise<string> {
  if (isOffline()) { lastMode = 'offline'; return qwenChat(prompt, onChunk); }
  let firstError: unknown;
  try { const out = await puterOnly(prompt, image, onChunk); if (out.trim()) { lastMode = 'online'; return out; } } catch (e) { firstError = e; }
  try { const out = await pollinationsChat(prompt, onChunk); lastMode = 'limit'; return out; } catch { throw wrap(firstError ?? new Error('ETEMBE AI could not respond.')); }
}
