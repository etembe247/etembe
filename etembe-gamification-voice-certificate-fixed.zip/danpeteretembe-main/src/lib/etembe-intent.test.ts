import { describe, expect, it } from 'vitest';
import { parseUserIntent, extractExtras } from './etembe-intent';

describe('intent parser', () => {
  it('accepts any typed career', () => {
    expect(parseUserIntent('Change my career to Beekeeper').career).toBe('Beekeeper');
  });
  it('roleplay becomes the mode', () => {
    const i = parseUserIntent('I want to chat with an angry customer');
    expect(i.action).toBe('change_mode');
    expect(i.roleplay).toBe('angry customer');
  });
  it('subject and class are free text', () => {
    expect(parseUserIntent('change my subject to Organic Chemistry').subject).toBe('Organic Chemistry');
    expect(parseUserIntent('change my class to JSS 2').class).toBe('JSS 2');
  });
  it('extracts image tag and task JSON from reply', () => {
    const r = extractExtras('Hello [IMAGE_GENERATE: a red heart]\n{"type":"quiz","title":"Q","question":"What is 2+2?","options":["3","4"],"points":10}');
    expect(r.text).toBe('Hello');
    expect(r.imagePrompt).toBe('a red heart');
    expect(r.task?.question).toBe('What is 2+2?');
  });
});
