export type ChatKind = 'career' | 'education';
export const recognitionSettings = (live: boolean) => ({ continuous: live, interimResults: false, lang: 'en-US' });
export const imagePrompt = (text: string) => text.match(/^(?:generate|create|draw|make)\s+(?:(?:an?|the)\s+)?(?:image|picture|photo|illustration)\s*(?:of|:)?\s*(.+)$/i)?.[1]?.trim() || null;
export function progressAfterLesson(lessons: number, streak: number, last: string | null, now = new Date()) {
  const today = now.toISOString().slice(0, 10);
  const yesterday = new Date(now.getTime() - 86400000).toISOString().slice(0, 10);
  return { lessons: lessons + 1, streak: last === today ? streak : last === yesterday ? streak + 1 : 1, last_active: today };
}
export type LearnStats = { streak: number; lessons_completed: number; avg_score: number; hours_learned: number; xp: number; week_days: number; week_start: string; last_active: string | null };
export const WEEKLY_GOAL = 7;
const isoDay = (d: Date) => d.toISOString().slice(0, 10);
export function weekStart(now = new Date()) { const d = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate())); d.setUTCDate(d.getUTCDate() - ((d.getUTCDay() + 6) % 7)); return isoDay(d); }
/** Each finished lesson: +1 lesson, +10 XP, minutes added to hours, streak grows once per day, quiz score averaged in. */
export function statsAfterActivity(s: LearnStats, minutes: number, score: number | null = null, now = new Date()): LearnStats {
  const today = isoDay(now), yesterday = isoDay(new Date(now.getTime() - 86400000)), week = weekStart(now);
  const newDay = s.last_active !== today;
  const lessons = s.lessons_completed + 1;
  return {
    streak: !newDay ? s.streak : s.last_active === yesterday ? s.streak + 1 : 1,
    lessons_completed: lessons,
    avg_score: score === null ? s.avg_score : Math.round(((s.avg_score * s.lessons_completed + score) / lessons) * 10) / 10,
    hours_learned: Math.round((s.hours_learned + minutes / 60) * 100) / 100,
    xp: s.xp + 10,
    week_days: s.week_start !== week ? 1 : newDay ? Math.min(WEEKLY_GOAL, s.week_days + 1) : s.week_days,
    week_start: week,
    last_active: today,
  };
}
