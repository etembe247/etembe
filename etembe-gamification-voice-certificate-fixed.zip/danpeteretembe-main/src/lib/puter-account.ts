// ETEMBE accounts run only on Puter.js: Puter sign-in + Puter KV per-user progress.
export type PuterUser = { username: string; uuid?: string; email?: string };
export type StoredMessage = { id: string; kind: 'career' | 'education'; role: 'user' | 'assistant'; content: string; image?: string | null };
export type Progress = { career?: string; avatar_initial?: string; memory?: unknown; chats?: StoredMessage[]; topic?: string; score?: number; date?: string; completed?: boolean; referrer?: string };

type PuterAuth = { isSignedIn: () => boolean; signIn: () => Promise<unknown>; signOut: () => void | Promise<void>; getUser: () => Promise<PuterUser> };
type PuterKV = { get: (k: string) => Promise<unknown>; set: (k: string, v: unknown) => Promise<unknown>; del: (k: string) => Promise<unknown> };
type PuterGlobal = { auth: PuterAuth; kv: PuterKV };

function puter(): PuterGlobal | null {
  return typeof window !== 'undefined' ? ((window as unknown as { puter?: PuterGlobal }).puter ?? null) : null;
}

/** Waits for the Puter script (loaded in the document head) to be ready. */
export async function waitForPuter(timeoutMs = 10000): Promise<PuterGlobal> {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    const p = puter();
    if (p?.auth) return p;
    await new Promise(r => setTimeout(r, 100));
  }
  throw new Error('ETEMBE could not load. Check your internet and try again.');
}

export const progressKey = (username: string) => `user:${username}:progress`;
export type SyncSlot = 'profile' | 'progress' | 'activities' | 'chat_history' | 'displayName' | 'avatar' | 'gamification' | 'badges';
export const syncKey = (username: string, slot: SyncSlot) => `etembe:${username}:${slot}`;
export const offlineQueueKey = 'etembe:offlineQueue';
// Chat history kept short so the per-user value stays small.
const MAX_CHATS = 200;

export async function isSignedIn() { return (await waitForPuter()).auth.isSignedIn(); }
export async function signIn() { const p = await waitForPuter(); await p.auth.signIn(); return p.auth.getUser(); }
export async function getUser() { return (await waitForPuter()).auth.getUser(); }
export async function signOut() { await (await waitForPuter()).auth.signOut(); }

export async function loadProgress(username: string): Promise<Progress> {
  const raw = await (await waitForPuter()).kv.get(progressKey(username));
  if (!raw) return {};
  try { return (typeof raw === 'string' ? JSON.parse(raw) : raw) as Progress; } catch { return {}; }
}

export async function saveProgress(username: string, data: Progress) {
  const trimmed = { ...data, chats: (data.chats ?? []).slice(-MAX_CHATS) };
  await (await waitForPuter()).kv.set(progressKey(username), JSON.stringify(trimmed));
}

export async function deleteProgress(username: string) {
  await (await waitForPuter()).kv.del(progressKey(username));
}

function readLocal<T>(key: string): T | null {
  try { const raw = localStorage.getItem(key); return raw ? JSON.parse(raw) as T : null; } catch { return null; }
}

function queueOffline(key: string, value: unknown) {
  try {
    const queue = readLocal<Array<{ key: string; value: string }>>(offlineQueueKey) ?? [];
    const next = queue.filter(item => item.key !== key); next.push({ key, value: JSON.stringify(value) });
    localStorage.setItem(offlineQueueKey, JSON.stringify(next));
  } catch { /* storage is best effort */ }
}

export async function loadSyncedSlot<T>(username: string, slot: SyncSlot): Promise<T | null> {
  const key = syncKey(username, slot);
  const local = readLocal<T>(key);
  try {
    const raw = await (await waitForPuter()).kv.get(key);
    if (raw !== null && raw !== undefined && raw !== '') {
      const data = (typeof raw === 'string' ? JSON.parse(raw) : raw) as T;
      localStorage.setItem(key, JSON.stringify(data));
      return data;
    }
    if (local !== null) { await (await waitForPuter()).kv.set(key, JSON.stringify(local)); return local; }
  } catch { /* use local data and queue future writes */ }
  return local;
}

export async function saveSyncedSlot(username: string, slot: SyncSlot, data: unknown) {
  const key = syncKey(username, slot);
  localStorage.setItem(key, JSON.stringify(data));
  if (typeof navigator !== 'undefined' && navigator.onLine === false) { queueOffline(key, data); return; }
  try { await (await waitForPuter()).kv.set(key, JSON.stringify(data)); }
  catch { queueOffline(key, data); }
}

export async function clearSyncedSlot(username: string, slot: SyncSlot) {
  const key = syncKey(username, slot);
  try { localStorage.removeItem(key); } catch { /* blocked */ }
  try { await (await waitForPuter()).kv.del(key); } catch { queueOffline(key, '__DELETE__'); }
}

export async function syncOfflineQueue() {
  if (typeof navigator !== 'undefined' && navigator.onLine === false) return;
  const queue = readLocal<Array<{ key: string; value: string }>>(offlineQueueKey) ?? [];
  if (!queue.length) return;
  try {
    const p = await waitForPuter();
    for (const item of queue) {
      if (item.value === '__DELETE__') await p.kv.del(item.key);
      else await p.kv.set(item.key, item.value);
    }
    localStorage.removeItem(offlineQueueKey);
  } catch { /* retry on the next online event */ }
}
