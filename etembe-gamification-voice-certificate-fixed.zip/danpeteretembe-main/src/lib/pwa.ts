export function isPreviewHost(hostname: string, delegatedHost = '') {
  const host = hostname.toLowerCase();
  if (delegatedHost && host === delegatedHost.toLowerCase()) return true;
  if (['lovableproject.com', 'lovableproject-dev.com', 'beta.lovable.dev'].some(domain => host === domain || host.endsWith(`.${domain}`))) return true;
  const managed = ['lovable.app', 'gpt-eng.com', 'gptengineer.run'].some(domain => host.endsWith(`.${domain}`));
  return managed && (/^(?:id-preview|preview)(?:-[a-z0-9]+)?--.+$/.test(host.split('.')[0] || '') || /^project--.+-dev$/.test(host.split('.')[0] || ''));
}

export function canRegisterAppWorker(production: boolean, framed: boolean, hostname: string, search: string) {
  return production && !framed && !isPreviewHost(hostname) && new URLSearchParams(search).get('sw') !== 'off';
}

export async function registerAppWorker() {
  if (!('serviceWorker' in navigator)) return;
  const allowed = canRegisterAppWorker(import.meta.env.PROD, window.self !== window.top, window.location.hostname, window.location.search);
  if (!allowed) {
    const registrations = await navigator.serviceWorker.getRegistrations();
    await Promise.all(registrations.filter(registration => [registration.active, registration.waiting, registration.installing].some(worker => worker && new URL(worker.scriptURL).pathname === '/sw.js')).map(registration => registration.unregister()));
    return;
  }
  const registration = await navigator.serviceWorker.register('/sw.js', { updateViaCache: 'none' });
  await registration.update().catch(() => {});
  void navigator.serviceWorker.ready.then(async () => {
    if (!navigator.serviceWorker.controller) await new Promise<void>(resolve => navigator.serviceWorker.addEventListener('controllerchange', () => resolve(), { once: true }));
    // Cache the generic HTML shell after the first activation, not private account data.
    await fetch('/', { credentials: 'omit', headers: { 'X-ETEMBE-Shell': '1' } });
  }).catch(() => {});
}
