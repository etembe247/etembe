import { describe, expect, it } from 'vitest';
import { canRegisterAppWorker, isPreviewHost } from './pwa';
import manifest from '../../public/manifest.json';

describe('ETEMBE installation and offline safety', () => {
  it('uses the requested home-screen name, colors, icon sizes, and standalone mode', () => {
    expect(manifest.name).toBe('ETEMBE'); expect(manifest.short_name).toBe('ETEMBE');
    expect(manifest.theme_color).toBe('#8B7CF8'); expect(manifest.background_color).toBe('#FCFBFF');
    expect(manifest.display).toBe('standalone'); expect(manifest.icons.map(icon => icon.sizes)).toEqual(['192x192', '512x512']);
  });
  it('refuses dev, iframe, all managed preview variants, and the kill switch', () => {
    expect(canRegisterAppWorker(false, false, 'learnwell.example', '')).toBe(false);
    expect(canRegisterAppWorker(true, true, 'learnwell.example', '')).toBe(false);
    for (const host of ['id-preview--abc.lovable.app', 'preview-v2--abc.gpt-eng.com', 'project--abc-dev.lovable.app', 'x.lovableproject.com', 'x.lovableproject-dev.com', 'x.beta.lovable.dev']) expect(canRegisterAppWorker(true, false, host, '')).toBe(false);
    expect(canRegisterAppWorker(true, false, 'learnwell.example', '?sw=off')).toBe(false);
    expect(isPreviewHost('delegated.example', 'delegated.example')).toBe(true);
  });
  it('allows published custom domains including preview-like labels', () => {
    expect(canRegisterAppWorker(true, false, 'learnwell.lovable.app', '')).toBe(true);
    expect(canRegisterAppWorker(true, false, 'preview-v2--shop.example.com', '')).toBe(true);
  });
});