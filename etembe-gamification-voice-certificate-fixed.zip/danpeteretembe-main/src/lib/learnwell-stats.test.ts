import { describe, it, expect } from 'vitest';
import { statsAfterActivity, type LearnStats } from './learnwell-rules';
const base: LearnStats = { streak: 2, lessons_completed: 4, avg_score: 50, hours_learned: 1, xp: 40, week_days: 2, week_start: '2026-10-26', last_active: '2026-10-27' };
const now = new Date('2026-10-28T10:00:00Z');
describe('Learning stats', () => {
  it('grows the streak on the next day', () => expect(statsAfterActivity(base, 6, null, now).streak).toBe(3));
  it('resets the streak after a missed day', () => expect(statsAfterActivity({ ...base, last_active: '2026-10-25' }, 6, null, now).streak).toBe(1));
  it('gives 10 XP and one lesson per activity', () => { const r = statsAfterActivity(base, 6, null, now); expect(r.xp).toBe(50); expect(r.lessons_completed).toBe(5); });
  it('adds minutes to hours learned', () => expect(statsAfterActivity(base, 30, null, now).hours_learned).toBe(1.5));
  it('averages quiz scores', () => expect(statsAfterActivity(base, 6, 100, now).avg_score).toBe(60));
  it('counts a new day toward the weekly goal and restarts on a new week', () => {
    expect(statsAfterActivity(base, 6, null, now).week_days).toBe(3);
    expect(statsAfterActivity(base, 6, null, new Date('2026-11-02T10:00:00Z')).week_days).toBe(1);
  });
});
