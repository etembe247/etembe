// Free-text intent parser: whatever the learner types is a valid career, subject, class or mode.
export type Intent = {
  action: 'chat' | 'change_career' | 'change_subject' | 'change_class' | 'change_mode' | 'generate_image_and_quiz';
  career: string | null; mode: string | null; roleplay: string | null; subject: string | null; class: string | null;
};

const clean = (s: string) => s.trim().replace(/^(to|into|a|an|my)\s+/i, '').replace(/^(a|an)\s+/i, '').replace(/[.!?]+$/, '').trim();

export function parseUserIntent(rawInput: string): Intent {
  const lower = rawInput.toLowerCase();
  const intent: Intent = { action: 'chat', career: null, mode: null, roleplay: null, subject: null, class: null };
  const roleplay = rawInput.match(/(?:chat with|talk to|act as|pretend to be|roleplay as)\s+(.+)/i)?.[1];
  const career = rawInput.match(/(?:change my career to|switch career to)\s+(.+)/i)?.[1];
  const subject = rawInput.match(/(?:change my subject to|change topic to)\s+(.+)/i)?.[1];
  const klass = rawInput.match(/change (?:my )?class to\s+(.+)/i)?.[1];
  if (career) { intent.action = 'change_career'; intent.career = clean(career); }
  else if (subject) { intent.action = 'change_subject'; intent.subject = clean(subject); }
  else if (klass) { intent.action = 'change_class'; intent.class = clean(klass); }
  else if (roleplay) { intent.action = 'change_mode'; intent.mode = rawInput.trim(); intent.roleplay = clean(roleplay); }
  if (/generate (an )?image|create (an )?image|\bdraw\b|image quiz/.test(lower)) intent.action = 'generate_image_and_quiz';
  return intent;
}

export type Task = { type: string; title: string; question: string; options?: string[]; correctAnswer?: string; imagePrompt?: string; points?: number };

/** Pull [IMAGE_GENERATE: ...] and the trailing task JSON out of an AI reply. */
export function extractExtras(reply: string): { text: string; imagePrompt: string | null; task: Task | null } {
  let text = reply;
  const img = text.match(/\[IMAGE_GENERATE:\s*([^\]]+)\]/i);
  text = text.replace(/\[IMAGE_GENERATE:[^\]]*\]/gi, '');
  let task: Task | null = null;
  const json = text.match(/```(?:json)?\s*(\{[\s\S]*?"question"[\s\S]*?\})\s*```|(\{[^{}]*"question"[^{}]*(?:\[[^\]]*\][^{}]*)?\})/);
  if (json) {
    try { const t = JSON.parse(json[1] || json[2] || '') as Task; if (t?.question) { task = t; text = text.replace(json[0], ''); } } catch { /* leave text */ }
  }
  return { text: text.trim(), imagePrompt: img?.[1]?.trim() || task?.imagePrompt || null, task };
}

export function formatTask(task: Task): string {
  const opts = task.options?.length ? '\n' + task.options.map((o, i) => `${String.fromCharCode(65 + i)}) ${o}`).join('\n') : '';
  return `\n\n🎯 ${task.title || 'Your task'} (${task.points ?? 10} pts)\n${task.question}${opts}`;
}

export function buildSystemPrompt(o: { teacher: string; area: string; mode: string; inputType: string; history: string; memory: string; raw: string; messageCount?: number; longTopic?: boolean }) {
  const messageCount = o.messageCount ?? 1;
  const longTopic = o.longTopic ?? messageCount >= 3;
  return `You are ETEMBE AI - smart professor + career coach. Teach any career/education step-by-step: definition, why it matters, examples, real application. Simple English. Never ask to change career/subject. Never show [object Object]. Keep short: under 200 words; teaching maximum 400 words.
After 3+ messages on the same topic OR more than 400 words taught, auto-add:
Summary: 3 bullets
Assignment: 2 tasks
Quiz: 3 questions (2 MCQ + 1 open)
End with exactly: "Type your answers, I will mark you."
${longTopic ? `This is message ${messageCount} on the same topic, so include the required Summary, Assignment, Quiz, and exact ending now.` : 'Do not add the Summary, Assignment, or Quiz block yet unless the long-topic threshold is reached.'}

Current ${o.teacher === 'Career Coach' ? 'career' : 'subject/class'}: ${o.area || 'not chosen yet'}.
Current mode: ${o.mode || 'normal teaching'}.
Input type: ${o.inputType}.
${o.memory}
If an image was uploaded, describe it and solve or explain it. If a picture would help, include exactly one tag [IMAGE_GENERATE: detailed prompt].
If the learner submits quiz or assignment answers, mark each answer, give a score X/10, explain wrong answers, and say that the learner earned XP.

Conversation so far:
${o.history}
Learner: ${o.raw}
${o.teacher}:`;
}
