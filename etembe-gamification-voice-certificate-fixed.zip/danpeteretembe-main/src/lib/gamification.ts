import { saveSyncedSlot, waitForPuter } from './puter-account';

export type BadgeId = 'first-lesson' | 'streak-3' | 'streak-7' | 'quiz-master' | 'xp-100' | 'xp-500';
export type Badge = { id: BadgeId; label: string; emoji: string; unlocked: boolean };
export type ScoreRecord = { topic: string; score: number; date: string; completed: true; kind?: 'career' | 'education' };
export type GamificationState = { xp: number; lastActiveDate: string; streak: number; badges: BadgeId[]; scores: ScoreRecord[] };
export type LeaderboardEntry = { displayName: string; avatar: string; XP: number; level: number; username?: string };

export const badgeCatalog: Array<Omit<Badge, 'unlocked'>> = [
  { id: 'first-lesson', label: 'First Lesson', emoji: '🌱' },
  { id: 'streak-3', label: '3-Day Streak', emoji: '🔥' },
  { id: 'streak-7', label: '7-Day Streak', emoji: '🔥' },
  { id: 'quiz-master', label: 'Quiz Master', emoji: '🏆' },
  { id: 'xp-100', label: '100 XP', emoji: '⭐' },
  { id: 'xp-500', label: '500 XP', emoji: '💎' },
];

export const levelForXp = (xp: number) => Math.floor(Math.max(0, xp) / 100) + 1;
export const levelProgress = (xp: number) => Math.max(0, xp) % 100;
const today = () => new Date().toISOString().slice(0, 10);
const localKey = (username: string, suffix: string) => `etembe:${username}:${suffix}`;

function readLocal<T>(key: string, fallback: T): T {
  try { return JSON.parse(localStorage.getItem(key) || '') as T; } catch { return fallback; }
}
function writeLocal(key: string, value: unknown) {
  try { localStorage.setItem(key, JSON.stringify(value)); } catch { /* best effort */ }
}
async function readKv<T>(key: string, fallback: T): Promise<T> {
  try {
    const raw = await (await waitForPuter()).kv.get(key);
    if (raw !== null && raw !== undefined && raw !== '') return (typeof raw === 'string' ? JSON.parse(raw) : raw) as T;
  } catch { /* local fallback */ }
  return readLocal(key, fallback);
}
async function writeKv(key: string, value: unknown) {
  writeLocal(key, value);
  const serialized = JSON.stringify(value);
  if (typeof navigator !== 'undefined' && navigator.onLine === false) {
    const queued = readLocal<Array<{ key: string; value: string }>>('etembe:offlineQueue', []);
    writeLocal('etembe:offlineQueue', [...queued.filter(item => item.key !== key), { key, value: serialized }]);
    return;
  }
  try { await (await waitForPuter()).kv.set(key, serialized); } catch {
    const queued = readLocal<Array<{ key: string; value: string }>>('etembe:offlineQueue', []);
    writeLocal('etembe:offlineQueue', [...queued.filter(item => item.key !== key), { key, value: serialized }]);
  }
}

export function emptyGamification(): GamificationState { return { xp: 0, lastActiveDate: '', streak: 0, badges: [], scores: [] }; }
export function badgesFor(state: GamificationState): Badge[] {
  return badgeCatalog.map(badge => ({ ...badge, unlocked: state.badges.includes(badge.id) }));
}

export async function loadGamification(username: string): Promise<GamificationState> {
  const fallback = readLocal<GamificationState>(localKey(username, 'gamification'), emptyGamification());
  const value = await readKv(localKey(username, 'gamification'), fallback);
  const normalized = { ...emptyGamification(), ...(value || {}) };
  writeLocal(localKey(username, 'gamification'), normalized);
  return normalized;
}

export async function saveGamification(username: string, state: GamificationState) {
  await saveSyncedSlot(username, 'gamification', state);
  await saveSyncedSlot(username, 'badges', state.badges);
}

export async function awardCompletion(username: string, current: GamificationState, options: { topic: string; score?: number | null; kind?: 'career' | 'education' }): Promise<GamificationState> {
  const date = today();
  const previous = current.lastActiveDate;
  const yesterday = new Date(Date.now() - 86400000).toISOString().slice(0, 10);
  const streak = previous === date ? Math.max(1, current.streak) : previous === yesterday ? current.streak + 1 : 1;
  const xp = current.xp + 10;
  const scores: ScoreRecord[] = options.score == null ? current.scores : [...current.scores, { topic: options.topic, score: Math.max(0, Math.min(100, options.score)), date, completed: true, ...(options.kind ? { kind: options.kind } : {}) }];
  const badges = new Set(current.badges);
  if (scores.length >= 1) badges.add('first-lesson');
  if (streak >= 3) badges.add('streak-3');
  if (streak >= 7) badges.add('streak-7');
  if (options.score === 100) badges.add('quiz-master');
  if (xp >= 100) badges.add('xp-100');
  if (xp >= 500) badges.add('xp-500');
  const next = { xp, lastActiveDate: date, streak, badges: [...badges], scores };
  await saveGamification(username, next);
  return next;
}

export async function loadLeaderboard(): Promise<LeaderboardEntry[]> {
  const key = 'etembe:leaderboard';
  const value = await readKv<LeaderboardEntry[]>(key, []);
  return Array.isArray(value) ? value : [];
}
export async function updateLeaderboard(entry: LeaderboardEntry): Promise<LeaderboardEntry[]> {
  const current = await loadLeaderboard();
  const next = [...current.filter(item => item.username !== entry.username || !entry.username), entry].sort((a, b) => b.XP - a.XP).slice(0, 100);
  await writeKv('etembe:leaderboard', next);
  return next;
}

export const scoreSummary = (scores: ScoreRecord[]) => ({
  totalQuizzes: scores.length,
  average: scores.length ? Math.round(scores.reduce((sum, item) => sum + item.score, 0) / scores.length) : 0,
  completedTopics: new Set(scores.map(item => item.topic)).size,
});
