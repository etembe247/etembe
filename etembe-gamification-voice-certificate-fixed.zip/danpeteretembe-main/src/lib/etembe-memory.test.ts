import { describe, expect, it } from 'vitest';
import { emptyMemory, recordCompletion, memoryContext, memoryStats, welcomeBack } from './etembe-memory';

describe('etembe memory', () => {
  it('records a real completion: lesson counted once, attempts and totals grow', () => {
    const m = recordCompletion(emptyMemory(), 'careers', 'Chef', 'Knife skills', 70, 'Teach Me');
    expect(m.totalLessons).toBe(1);
    expect(m.careers['Chef']?.lessons).toEqual(['Knife skills']);
    expect(m.careers['Chef']?.attempts).toBe(1);
    const again = recordCompletion(m, 'careers', 'Chef', 'Knife skills', 80, 'Quiz');
    expect(again.careers['Chef']?.lessons).toEqual(['Knife skills']);
    expect(again.careers['Chef']?.attempts).toBe(2);
    expect(again.totalLessons).toBe(2);
  });

  it('memory context forbids repeating learned lessons and carries a uniqueness seed', () => {
    const m = recordCompletion(emptyMemory(), 'subjects', 'Math', 'Fractions', 90, 'Quiz');
    const ctx = memoryContext(m, 'subjects', 'Math');
    expect(ctx).toContain('Fractions');
    expect(ctx).toContain('DO NOT repeat');
    expect(ctx).toMatch(/Seed \d+/);
  });

  it('first-time context says beginner and stays unique', () => {
    expect(memoryContext(emptyMemory(), 'careers', 'Beekeeping')).toContain('First time learning Beekeeping');
  });

  it('stats come only from recorded completions — no fake numbers', () => {
    const empty = memoryStats(emptyMemory());
    expect(empty).toMatchObject({ lessons: 0, score: 0, streak: 0 });
    let m = recordCompletion(emptyMemory(), 'careers', 'Nurse', 'Basics', 80, 'Quiz');
    m = recordCompletion(m, 'subjects', 'Math', 'Algebra', 60, 'Assignment');
    const stats = memoryStats(m);
    expect(stats.lessons).toBe(2);
    expect(stats.score).toBe(70);
    expect(stats.streak).toBe(1);
    expect(stats.xp).toBe(20);
  });

  it('welcome back line shows level, lesson count and last score', () => {
    const m = recordCompletion(emptyMemory(), 'careers', 'Pilot', 'Takeoff', 85, 'Teach Me');
    expect(welcomeBack(m, 'careers', 'Pilot')).toBe('Welcome back to Pilot! Level advanced | 1 lessons | Last 85% → Next: new advanced topic');
    expect(welcomeBack(emptyMemory(), 'careers', 'Pilot')).toBeNull();
  });
});
