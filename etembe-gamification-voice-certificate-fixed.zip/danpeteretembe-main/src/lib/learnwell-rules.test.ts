import { describe, it, expect } from 'vitest';
import { recognitionSettings, imagePrompt } from './learnwell-rules';
describe('Requested voice modes', () => {
  it('listens continuously with final English transcripts in live mode', () => {
    expect(recognitionSettings(true)).toEqual({ continuous: true, interimResults: false, lang: 'en-US' });
  });
  it('uses one-time recognition for microphone input', () => {
    expect(recognitionSettings(false).continuous).toBe(false);
  });
  it('routes an image generation command to its image prompt', () => {
    expect(imagePrompt('Generate an image of a neuron')).toBe('a neuron');
    expect(imagePrompt('Explain a neuron')).toBeNull();
  });
});