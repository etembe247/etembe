export type AreaMemory = { lessons: string[]; scores: number[]; modesDone: string[]; level: string; attempts: number; lastSeen: string };
export type EtembeMemory = {
  userId: string;
  name: string;
  subject: string;
  careers: Record<string, AreaMemory>;
  subjects: Record<string, AreaMemory>;
  totalLessons: number;
  strengths: string[];
  weaknesses: string[];
  days: string[];
};

const STORAGE_KEY = 'etembe_memory';

export const emptyMemory = (): EtembeMemory => ({
  userId: crypto.randomUUID(),
  name: '',
  subject: '',
  careers: {},
  subjects: {},
  totalLessons: 0,
  strengths: [],
  weaknesses: [],
  days: [],
});

export function loadMemory(): EtembeMemory {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) return { ...emptyMemory(), ...(JSON.parse(raw) as Partial<EtembeMemory>) };
  } catch { /* corrupted or unavailable storage */ }
  return emptyMemory();
}

export function saveMemoryLocal(memory: EtembeMemory) {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(memory)); } catch { /* storage full/blocked */ }
}

const isoDay = (d: Date) => d.toISOString().slice(0, 10);

/** Record one real completion (lesson, task, quiz, simulation) for a career or subject. Pure: returns a new memory object. */
export function recordCompletion(memory: EtembeMemory, area: 'careers' | 'subjects', name: string, title: string, score: number | null, mode: string, now = new Date()): EtembeMemory {
  const key = name.trim() || 'General';
  const previous = memory[area][key] ?? { lessons: [], scores: [], modesDone: [], level: 'beginner', attempts: 0, lastSeen: '' };
  const scores = score === null ? previous.scores : [...previous.scores, score];
  const avg = scores.length ? scores.reduce((a, b) => a + b, 0) / scores.length : 0;
  const next: AreaMemory = {
    lessons: [...new Set([...previous.lessons, title])],
    scores,
    modesDone: [...new Set([...previous.modesDone, mode])],
    level: avg >= 80 || previous.attempts + 1 >= 10 ? 'advanced' : avg >= 50 || previous.attempts + 1 >= 4 ? 'intermediate' : 'beginner',
    attempts: previous.attempts + 1,
    lastSeen: now.toISOString(),
  };
  const today = isoDay(now);
  return {
    ...memory,
    [area]: { ...memory[area], [key]: next },
    totalLessons: memory.totalLessons + 1,
    days: memory.days.includes(today) ? memory.days : [...memory.days, today],
  };
}

/** Context prepended to every AI prompt so ETEMBE never repeats the same lesson and always teaches the next level. */
export function memoryContext(memory: EtembeMemory, area: 'careers' | 'subjects', name: string): string {
  const key = name.trim() || 'General';
  const mem = memory[area][key];
  const seed = `Seed ${Date.now()} ${Math.random()} for uniqueness.`;
  if (!mem) return `First time learning ${key} for this user, start at beginner level. ${seed}`;
  return `MEMORY for ${key}: Learned: ${mem.lessons.join(', ') || 'none'}. Scores: ${mem.scores.join(', ') || 'none'}. Modes done: ${mem.modesDone.join(', ') || 'none'}. Level: ${mem.level}. Weaknesses: ${memory.weaknesses.join(', ') || 'none'}. RULE: DO NOT repeat the lessons above. Teach a NEW topic at the next level. Personalize. ${seed}`;
}

export type MemoryStats = { lessons: number; score: number; streak: number; weekDays: number; xp: number; hours: number };

/** Real counts derived only from recorded completions — never fake numbers. */
export function memoryStats(memory: EtembeMemory, now = new Date()): MemoryStats {
  const allScores = [...Object.values(memory.careers), ...Object.values(memory.subjects)].flatMap(a => a.scores);
  const score = allScores.length ? Math.round(allScores.reduce((a, b) => a + b, 0) / allScores.length) : 0;
  let streak = 0;
  const cursor = new Date(now);
  if (!memory.days.includes(isoDay(cursor))) cursor.setUTCDate(cursor.getUTCDate() - 1);
  while (memory.days.includes(isoDay(cursor))) { streak++; cursor.setUTCDate(cursor.getUTCDate() - 1); }
  const weekStart = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
  weekStart.setUTCDate(weekStart.getUTCDate() - ((weekStart.getUTCDay() + 6) % 7));
  const weekDays = memory.days.filter(d => d >= isoDay(weekStart)).length;
  return { lessons: memory.totalLessons, score, streak, weekDays, xp: memory.totalLessons * 10, hours: Math.round(memory.totalLessons * 0.1 * 10) / 10 };
}

/** One-line "welcome back" summary for the chat header, or null for a brand-new area. */
export function welcomeBack(memory: EtembeMemory, area: 'careers' | 'subjects', name: string): string | null {
  const mem = memory[area][name.trim() || 'General'];
  if (!mem || !mem.attempts) return null;
  const lastScore = mem.scores.length ? mem.scores[mem.scores.length - 1] : null;
  return `Welcome back to ${name}! Level ${mem.level} | ${mem.attempts} lessons${lastScore === null ? '' : ` | Last ${lastScore}%`} → Next: new ${mem.level} topic`;
}
