# Danpeteretembe

This my web app codes don not change anything until I said you change.



Now add a purple button of "Sign in" under the The "get started" button

This project was built with [Lovable](https://lovable.dev).

**Live app**: https://danpeteretembe.lovable.app

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/1a2d3b6b-e53d-4ef9-a2d2-1581c868cced).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
