// @lovable.dev/vite-tanstack-config already includes the following — do NOT add them manually
// or the app will break with duplicate plugins:
//   - TanStack devtools (dev-only, first), tanstackStart, viteReact, tailwindcss, tsConfigPaths,
//     nitro (build-only using cloudflare as a default target), VITE_* env injection, @ path alias,
//     React/TanStack dedupe, error logger plugins, and sandbox detection (port/host/strictPort).
// You can pass additional config via defineConfig({ vite: { ... }, etc... }) if needed.
import { defineConfig } from "@lovable.dev/vite-tanstack-config";
import { VitePWA } from "vite-plugin-pwa";

export default defineConfig({
  plugins: [VitePWA({
    strategies: 'generateSW',
    outDir: '.output/public',
    filename: 'sw.js',
    manifest: false,
    injectRegister: null,
    registerType: 'autoUpdate',
    devOptions: { enabled: false },
    includeAssets: ['icon-192.png', 'icon-512.png', 'apple-touch-icon.png', 'favicon.png', 'book-logo.svg', 'manifest.json'],
    workbox: {
      globPatterns: ['assets/**/*.{js,css,png,jpg,webp,woff,woff2}', '*.{png,svg,json}'],
      globIgnores: ['**/app.html', '**/server/**'],
      maximumFileSizeToCacheInBytes: 8 * 1024 * 1024,
      navigateFallback: null,
      cleanupOutdatedCaches: true,
      runtimeCaching: [
        {
          urlPattern: ({ request, url }) => request.method === 'GET' && (request.mode === 'navigate' || request.headers.get('X-LearnWell-Shell') === '1') && url.origin === self.location.origin && url.pathname === '/' && !url.search,
          handler: 'NetworkFirst',
          options: { cacheName: 'learnwell-shell', networkTimeoutSeconds: 4, cacheableResponse: { statuses: [200] }, expiration: { maxEntries: 1, maxAgeSeconds: 30 * 86400 } },
        },
        {
          urlPattern: ({ url }) => url.origin === self.location.origin && /^\/assets\/[^/]+-[\w-]{8,}\.(?:js|css|png|jpg|webp|woff2?)$/.test(url.pathname),
          handler: 'CacheFirst',
          options: { cacheName: 'learnwell-assets', expiration: { maxEntries: 100, maxAgeSeconds: 30 * 86400 } },
        },
        {
          urlPattern: ({ request, url }) => request.method === 'GET' && ['api.puter.com', 'text.pollinations.ai', 'image.pollinations.ai'].includes(url.hostname),
          handler: 'NetworkFirst',
          options: { cacheName: 'learnwell-api', networkTimeoutSeconds: 5, cacheableResponse: { statuses: [200] }, expiration: { maxEntries: 50, maxAgeSeconds: 86400 } },
        },
      ],
    },
  })],
  tanstackStart: {
    // Redirect TanStack Start's bundled server entry to src/server.ts (our SSR error wrapper).
    // nitro/vite builds from this
    server: { entry: "server" },
  },
});
