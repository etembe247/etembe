import { defineConfig } from "vitest/config";
import react from "@vitejs/plugin-react";
import path from "node:path";

export default defineConfig({
  plugins: [react(), {
    name: 'mock-pwa-registration',
    resolveId(id) { return id === 'virtual:pwa-register' ? '\0test:pwa-register' : null; },
    load(id) { return id === '\0test:pwa-register' ? 'export const registerSW = () => () => Promise.resolve();' : null; },
  }],
  test: {
    environment: "jsdom",
    globals: true,
    setupFiles: ["./src/test/setup.ts"],
    include: ["src/**/*.{test,spec}.{ts,tsx}"],
  },
  resolve: {
    alias: { "@": path.resolve(__dirname, "./src") },
  },
});
